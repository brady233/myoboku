package com.shinobiarts.client;

import com.shinobiarts.ninja.NinjaData;
import net.minecraft.nbt.CompoundTag;

/**
 * The local player's ninja data as last sent by the server. Holds no client-only classes,
 * so common code (like item tooltips) can safely read it.
 */
public final class ClientNinjaData {
    private static NinjaData data = new NinjaData();
    /** Server game time of the last sync (timers like the XP boost count down from it). */
    private static long syncTime;
    /** The player's team as shown in the stats menu (see TeamManager.clientInfo). */
    private static CompoundTag team = new CompoundTag();

    private ClientNinjaData() {}

    public static NinjaData get() {
        return data;
    }

    public static void apply(CompoundTag tag) {
        data.load(tag);
        syncTime = tag.getLong("SyncTime");
        team = tag.getCompound("Team");
    }

    public static long syncTime() {
        return syncTime;
    }

    public static CompoundTag team() {
        return team;
    }

    public static void reset() {
        data = new NinjaData();
        team = new CompoundTag();
        syncTime = 0;
    }
}
