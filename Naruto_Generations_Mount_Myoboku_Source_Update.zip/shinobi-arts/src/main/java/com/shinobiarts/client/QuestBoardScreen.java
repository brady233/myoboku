package com.shinobiarts.client;

import com.shinobiarts.network.BoardActionPacket;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.quest.PlayerQuests;
import com.shinobiarts.quest.QuestItems;
import com.shinobiarts.registry.ModItems;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * The village quest board (/village): tabs for the hourly, daily, weekly and monthly quests and the Kage's
 * village quests. Accept or decline a quest, watch its progress, and claim the reward once it's complete.
 */
public class QuestBoardScreen extends Screen {
    static final String[] TABS = {"hourly", "daily", "weekly", "monthly", "kage"};
    private static final int W = 340, H = 214, ROW_H = 40, ROWS = 4;
    private static int tab = 1;

    private CompoundTag board;
    private int page;
    private long openedAt;
    private int left;
    private int top;

    public QuestBoardScreen(CompoundTag board) {
        super(Component.translatable("screen.shinobiarts.quest_board"));
        this.board = board;
        this.openedAt = System.currentTimeMillis();
    }

    /** New data from the server after a button press. */
    public void update(CompoundTag board) {
        this.board = board;
        this.openedAt = System.currentTimeMillis();
        rebuildWidgets();
    }

    private ListTag rows() {
        return board.getList(TABS[tab], Tag.TAG_COMPOUND);
    }

    @Override
    protected void init() {
        left = (this.width - W) / 2;
        top = Math.max(16, (this.height - H) / 2);
        int tx = left + 6;
        for (int i = 0; i < TABS.length; i++) {
            int index = i;
            Button b = addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.tab." + TABS[i]), x -> {
                tab = index;
                page = 0;
                rebuildWidgets();
            }).bounds(tx, top + 22, 64, 16).build());
            b.active = i != tab;
            tx += 66;
        }
        if (board.getBoolean("Kage")) {
            addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.kage_menu"),
                    b -> ModNetwork.toServer(new BoardActionPacket(BoardActionPacket.OPEN_KAGE, "", 0, 0, 0)))
                    .bounds(left + W - 76, top + 4, 70, 14).build());
        }
        ListTag rows = rows();
        int pages = Math.max(1, (rows.size() + ROWS - 1) / ROWS);
        page = Math.min(page, pages - 1);
        for (int i = page * ROWS; i < Math.min(rows.size(), (page + 1) * ROWS); i++) {
            CompoundTag r = rows.getCompound(i);
            int y = top + 44 + (i - page * ROWS) * ROW_H;
            String uid = r.getString("Uid");
            int status = r.getInt("Status");
            int bx = left + W - 66;
            if (status == PlayerQuests.OFFERED) {
                addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.accept"),
                        b -> ModNetwork.toServer(new BoardActionPacket(BoardActionPacket.ACCEPT, uid, 0, 0, 0)))
                        .bounds(bx, y + 4, 60, 14).build());
                addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.decline"),
                        b -> ModNetwork.toServer(new BoardActionPacket(BoardActionPacket.DECLINE, uid, 0, 0, 0)))
                        .bounds(bx, y + 20, 60, 14).build());
            } else if (status == PlayerQuests.COMPLETE) {
                addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.claim"),
                        b -> ModNetwork.toServer(new BoardActionPacket(BoardActionPacket.CLAIM, uid, 0, 0, 0)))
                        .bounds(bx, y + 11, 60, 16).build());
            }
        }
        if (pages > 1) {
            addRenderableWidget(Button.builder(Component.literal("<"), b -> {
                page = Math.max(0, page - 1);
                rebuildWidgets();
            }).bounds(left + W / 2 - 40, top + H - 18, 20, 14).build()).active = page > 0;
            addRenderableWidget(Button.builder(Component.literal(">"), b -> {
                page = Math.min(pages - 1, page + 1);
                rebuildWidgets();
            }).bounds(left + W / 2 + 20, top + H - 18, 20, 14).build()).active = page < pages - 1;
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        StatScreen.panel(g, left, top, W, H);
        g.drawString(this.font, Component.translatable("screen.shinobiarts.board_title", board.getString("Village")), left + 8, top + 7,
                StatScreen.INK, false);
        ListTag rows = rows();
        if (rows.isEmpty()) {
            Component empty = Component.translatable(tab == 4 ? "screen.shinobiarts.no_kage_quests" : "screen.shinobiarts.no_quests");
            g.drawString(this.font, empty, left + W / 2 - this.font.width(empty) / 2, top + 100, StatScreen.INK_SOFT, false);
        }
        for (int i = page * ROWS; i < Math.min(rows.size(), (page + 1) * ROWS); i++) {
            renderRow(g, rows.getCompound(i), left + 8, top + 44 + (i - page * ROWS) * ROW_H);
        }
        int resetW = 0;
        if (tab < 4) {
            long secs = Math.max(0, board.getLong(TABS[tab] + "Reset") - (System.currentTimeMillis() - openedAt) / 1000);
            Component reset = Component.translatable("screen.shinobiarts.resets_in", duration(secs));
            g.drawString(this.font, reset, left + 8, top + H - 15, StatScreen.INK_SOFT, false);
            resetW = this.font.width(reset);
        }
        // the advisors take what's left of the bottom line (right of the page arrows when there are pages)
        renderAdvisors(g, rows.size() > ROWS ? W / 2 - 52 : W - 26 - resetW);
        super.render(g, mouseX, mouseY, partialTick);
    }

    /** Bottom right: "Need help? Advisors: Steve, Alex +2" (online names in green). */
    private void renderAdvisors(GuiGraphics g, int maxW) {
        ListTag advisors = board.getList("advisors", Tag.TAG_COMPOUND);
        if (advisors.isEmpty()) return;
        net.minecraft.network.chat.MutableComponent line = Component.translatable("screen.shinobiarts.advisors").copy();
        int shown = 0;
        for (int i = 0; i < advisors.size(); i++) {
            CompoundTag a = advisors.getCompound(i);
            Component name = Component.literal((shown > 0 ? ", " : " ") + a.getString("Name"))
                    .withStyle(s -> s.withColor(a.getBoolean("Online") ? 0x1E7A2E : 0x5E6455));
            String more = " +" + (advisors.size() - i - 1);
            if (shown > 0 && this.font.width(line) + this.font.width(name) + this.font.width(more) > maxW) break;
            line.append(name);
            shown++;
        }
        if (shown < advisors.size()) line.append(Component.literal(" +" + (advisors.size() - shown)).withStyle(s -> s.withColor(0x5E6455)));
        g.drawString(this.font, line, left + W - 8 - this.font.width(line), top + H - 15, StatScreen.INK, false);
    }

    private void renderRow(GuiGraphics g, CompoundTag r, int x, int y) {
        drawRow(g, this.font, r, x, y, W - 16, ROW_H);
    }

    /** One quest row (also used by the Quests page of the stats menu): icon, title, progress bar, reward, state. */
    static void drawRow(GuiGraphics g, net.minecraft.client.gui.Font font, CompoundTag r, int x, int y, int w, int rowH) {
        g.fill(x - 2, y, x + w, y + rowH - 3, 0x14000000);
        g.renderItem(icon(r), x + 2, y + 10);
        Component title = Component.Serializer.fromJson(r.getString("Title"));
        if (title == null) title = Component.literal("?");
        int tx = x + 24;
        g.drawString(font, title, tx, y + 4, StatScreen.INK, false);
        if (!r.getString("By").isEmpty()) {
            Component by = Component.translatable("screen.shinobiarts.posted_by", r.getString("By"));
            g.drawString(font, by, tx + font.width(title) + 6, y + 4, StatScreen.INK_SOFT, false);
        }
        int count = Math.max(1, r.getInt("Count")), progress = r.getInt("Progress"), status = r.getInt("Status");
        int barW = 120;
        g.fill(tx, y + 16, tx + barW, y + 20, 0xFF8E9980);
        g.fill(tx + 1, y + 17, tx + barW - 1, y + 19, 0xFFF4F6EE);
        g.fill(tx + 1, y + 17, tx + 1 + Math.round((barW - 2) * Math.min(1f, progress / (float) count)), y + 19,
                status >= PlayerQuests.COMPLETE ? 0xFF3FAF46 : 0xFF4F8FDF);
        g.drawString(font, Math.min(progress, count) + "/" + count, tx + barW + 6, y + 14, StatScreen.INK_SOFT, false);
        Component reward = Component.translatable("screen.shinobiarts.reward", r.getInt("Bottles"), PlayerDataManager.formatRyo(r.getLong("Ryo")));
        g.drawString(font, reward, tx, y + 25, 0xFF7A4E00, false);
        if (r.contains("Scroll")) {                                  // the jutsu scroll it pays out too, in its rank's colour
            Component name = Component.Serializer.fromJson(r.getString("Scroll"));
            com.shinobiarts.jutsu.JutsuRank rank = com.shinobiarts.jutsu.JutsuRank.values()[
                    Math.max(0, Math.min(com.shinobiarts.jutsu.JutsuRank.values().length - 1, r.getInt("ScrollRank")))];
            if (name != null) {
                Component scroll = Component.translatable("screen.shinobiarts.reward_scroll", name, rank.name()).withStyle(rank.color());
                int sx = tx + font.width(reward) + 4;
                String fit = font.plainSubstrByWidth(scroll.getString(), Math.max(0, x + w - 6 - sx));
                g.drawString(font, fit, sx, y + 25, 0xFF000000 | (rank.color().getColor() == null ? 0x555555 : rank.color().getColor()), false);
            }
        }
        Component state = switch (status) {
            case PlayerQuests.ACCEPTED -> Component.translatable("screen.shinobiarts.in_progress");
            case PlayerQuests.CLAIMED -> Component.translatable("screen.shinobiarts.claimed");
            case PlayerQuests.DECLINED -> Component.translatable("screen.shinobiarts.declined");
            default -> null;
        };
        if (state != null) {
            int color = status == PlayerQuests.CLAIMED ? 0xFF1E7A2E : StatScreen.INK_SOFT;
            g.drawString(font, state, x + w - 6 - font.width(state), y + 14, color, false);
        }
    }

    private static ItemStack icon(CompoundTag r) {
        String item = r.getString("Item");
        if (!item.isEmpty()) return new ItemStack(QuestItems.icon(item));
        String uid = r.getString("Title");
        if (uid.contains("kill_bandits")) return new ItemStack(ModItems.KUNAI.get());
        if (uid.contains("kill_players")) return new ItemStack(Items.PLAYER_HEAD);
        if (uid.contains("fish")) return new ItemStack(Items.COD);
        return new ItemStack(Items.IRON_SWORD);
    }

    static String duration(long secs) {
        if (secs >= 86400) return (secs / 86400) + "d " + (secs % 86400) / 3600 + "h";
        if (secs >= 3600) return (secs / 3600) + "h " + (secs % 3600) / 60 + "m";
        return (secs / 60) + "m " + (secs % 60) + "s";
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
