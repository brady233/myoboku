package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** Space-time ninjutsu: the Flying Thunder God's flash. */
final class FxSpaceTime {
    private FxSpaceTime() {}

    private static final int YELLOW = 0xFFE24A, GOLD = 0xFFB020, WHITE = 0xFFFFFF;

    /**
     * The Flying Thunder God: a yellow flash where the user vanishes or appears, streaks of light bursting out of it,
     * and a ring of light along the ground.
     */
    static void flash(FxClient.Ctx c) {
        Vec3 o = c.fx().a;
        float age = c.age(), p = c.progress(), s = c.fx().size;
        VertexConsumer add = FxDraw.additive(c.buffers());
        float burst = Mth.clamp(age / 3f, 0f, 1f);
        float fade = 1f - FxDraw.smooth(Math.max(0f, (age - 2f) / Math.max(1f, c.fx().ticks - 2f)));
        FxDraw.sphere(add, c.ps(), o, s * (0.3f + 1.5f * burst), 10, 14, FxDraw.addColor(YELLOW, 0.55f * fade), FxDraw.FULL);
        FxDraw.sphere(add, c.ps(), o, s * (0.15f + 0.6f * burst), 10, 14, FxDraw.addColor(WHITE, 0.9f * fade * (1 - p)), FxDraw.FULL);
        RandomSource r = FxDraw.rng(c.fx().seed, 21);
        for (int k = 0; k < 14; k++) {                      // streaks of light flying out
            Vec3 dir = new Vec3(r.nextGaussian(), r.nextGaussian() * 0.6, r.nextGaussian()).normalize();
            float len = s * (1.2f + r.nextFloat() * 1.6f);
            float t = Mth.clamp(age / (4f + r.nextFloat() * 4f), 0f, 1f);
            if (t >= 1f) continue;
            Vec3 a = o.add(dir.scale(len * t * 0.6)), b = o.add(dir.scale(len * (0.25 + t)));
            FxDraw.ribbon(add, c.ps(), c.cam(), List.of(a, a.lerp(b, 0.5), b), 0.09f * s, 0.2f,
                    FxDraw.addColor(GOLD, 0f), FxDraw.addColor(k % 3 == 0 ? WHITE : YELLOW, 0.9f * (1 - t)), FxDraw.FULL);
        }
        double gy = FxDraw.groundY(o) + 0.05;
        float rr = s * (0.4f + 2.2f * FxDraw.smooth(Math.min(1f, age / 8f)));
        FxDraw.ring(add, c.ps(), new Vec3(o.x, gy, o.z), new Vec3(0, 1, 0), rr, 0.18f * s * (1 - p) + 0.02f, 40,
                FxDraw.addColor(YELLOW, 0.8f * (1 - p)), FxDraw.addColor(GOLD, 0f), FxDraw.FULL);
    }

    /**
     * Kamui's vortex (entityA, or a), seen from outside: a spiral of space itself, dark purple arms wound tight round
     * a black heart, spinning faster and pulling in as the body twists into it ({@code out}: unwinding as someone
     * comes out of it). Obito's own warp spirals out of his eye.
     */
    static void kamuiSwirl(FxClient.Ctx c, boolean out) {
        net.minecraft.world.entity.Entity e = c.fx().entityA();
        Vec3 o = e == null ? c.fx().a : e.getPosition(c.partial()).add(0, e.getBbHeight() * 0.6, 0);
        float p = c.progress(), s = c.fx().size;
        float open = out ? 1f - p : p;                       // how far the vortex has taken them
        float strength = Mth.sin(Mth.PI * Math.min(1f, p * 1.05f));
        Vec3 view = c.cam().subtract(o);
        if (view.lengthSqr() < 1e-6) return;
        view = view.normalize();
        Vec3 u = FxDraw.perpendicular(view), v = view.cross(u);
        VertexConsumer add = FxDraw.additive(c.buffers());
        VertexConsumer dark = FxDraw.lit(c.buffers());
        float spin = c.age() * (0.35f + open * 0.6f) * (out ? -1 : 1);
        float R = s * (1.4f - open * 0.7f);
        for (int arm = 0; arm < 6; arm++) {
            java.util.List<Vec3> pts = new java.util.ArrayList<>();
            for (int i = 0; i <= 18; i++) {
                float t = i / 18f;
                float a = spin + arm * Mth.TWO_PI / 6 + t * 5.5f;
                float r = R * (1 - t) + 0.05f;
                pts.add(o.add(u.scale(Mth.cos(a) * r)).add(v.scale(Mth.sin(a) * r)).add(view.scale(0.05 * t)));
            }
            FxDraw.ribbon(add, c.ps(), c.cam(), pts, 0.22f * s, 0.2f, FxDraw.addColor(0x2A0A3A, 0f), FxDraw.addColor(0x8A5AC8, 0.75f * strength), FxDraw.FULL);
            FxDraw.ribbon(dark, c.ps(), c.cam(), pts, 0.12f * s, 0.2f, FxDraw.color(0x0A0410, 0f), FxDraw.color(0x0A0410, 0.7f * strength), FxDraw.FULL);
        }
        FxDraw.ring(add, c.ps(), o, view, R * 0.9f, R * 0.25f, 40, FxDraw.addColor(0x5A2A8A, 0.4f * strength), FxDraw.addColor(0x5A2A8A, 0f), FxDraw.FULL);
        FxDraw.sphere(dark, c.ps(), o, 0.18f * s * strength, 6, 8, FxDraw.color(0x000000, 0.9f * strength), FxDraw.FULL);
    }
}
