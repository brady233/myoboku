package com.shinobiarts.network;

import com.shinobiarts.client.ClientEyes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Server -> client: how a player looks right now: the Sharingan on their face (stage and Mangekyou pattern),
 * Lightning Armor's glow and Kamui. Packed as in SharinganManager.look.
 */
public class EyesPacket {
    private final int entityId;
    private final int look;

    public EyesPacket(int entityId, int look) {
        this.entityId = entityId;
        this.look = look;
    }

    public EyesPacket(FriendlyByteBuf buf) {
        this.entityId = buf.readVarInt();
        this.look = buf.readVarInt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(entityId);
        buf.writeVarInt(look);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientEyes.set(entityId, look));
    }
}
