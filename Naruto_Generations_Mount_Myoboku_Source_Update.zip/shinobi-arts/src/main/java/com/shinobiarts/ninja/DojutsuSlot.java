package com.shinobiarts.ninja;

import com.mojang.datafixers.util.Pair;
import com.shinobiarts.ShinobiArts;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import com.shinobiarts.item.ActiveEyeItem;

import java.lang.reflect.Method;

/**
 * The dojutsu equipment slot: an extra slot in the player's inventory (above the off-hand). Empty, it shows a grey
 * Sharingan, the way empty armor slots show a grey helmet.
 * <ul>
 *   <li>Switching your eyes on (V) puts them in the slot (an {@link ActiveEyeItem}: your Sharingan at its stage and
 *       pattern, or the Byakugan), locked in place; switching them off takes them out again ({@link #sync}).</li>
 *   <li>While your eyes are off, the slot can hold a Sharingan item (cosmetic eyes). Switching your eyes on moves
 *       it back into your inventory.</li>
 * </ul>
 * What's in it is saved with the player's ninja data and shows on their face for everyone (see SharinganManager.look).
 *
 * <p>The slot is added to the player's own inventory menu on both sides when the player joins a world, always as
 * the slot right after vanilla's 46, so the server and client agree on its number.</p>
 */
public final class DojutsuSlot {
    /** Where the slot sits in the survival inventory screen: directly above the off-hand slot. */
    public static final int X = 77, Y = 44;
    /** The grey Sharingan shown in the empty slot (textures/item/empty_dojutsu_slot.png, on the block atlas). */
    public static final ResourceLocation EMPTY_ICON = ShinobiArts.id("item/empty_dojutsu_slot");

    private static final Method ADD_SLOT = findAddSlot();

    private DojutsuSlot() {}

    /** Only eye items go in the slot. */
    public static boolean accepts(ItemStack stack) {
        return stack.getItem() instanceof com.shinobiarts.item.SharinganItem;
    }

    /** What the player has in the slot (EMPTY if nothing). */
    public static ItemStack item(Player player) {
        NinjaData d = NinjaData.get(player);
        return d == null ? ItemStack.EMPTY : d.getDojutsuItem();
    }

    /**
     * Keeps the slot in step with the player's eyes: their switched-on eyes go in (replacing a worn Sharingan item,
     * which goes back to the inventory), and come out again when the eyes are switched off. Called right after the
     * V key and every tick (so eyes switched off by running out of chakra, dying, etc. leave the slot too).
     */
    public static void sync(ServerPlayer player) {
        NinjaData d = NinjaData.get(player);
        if (d == null) return;
        ItemStack current = d.getDojutsuItem();
        int want = ActiveEyeItem.variantFor(d);
        boolean changed = false;
        if (want >= 0) {
            if (!ActiveEyeItem.is(current) || ActiveEyeItem.variant(current) != want) {
                if (!current.isEmpty() && !ActiveEyeItem.is(current)) {
                    ItemStack worn = current.copy();   // a worn Sharingan item goes back to the inventory
                    if (!player.getInventory().add(worn)) player.drop(worn, false);
                }
                d.setDojutsuItem(ActiveEyeItem.create(want));
                changed = true;
            }
        } else if (ActiveEyeItem.is(current)) {
            d.setDojutsuItem(ItemStack.EMPTY);
            changed = true;
        }
        if (changed) {
            player.inventoryMenu.broadcastChanges();
            SharinganManager.updateLook(player);
        }
    }

    /** Active eyes only live in the dojutsu slot: any that end up elsewhere (creative copies) are removed. */
    public static void removeStrayEyes(ServerPlayer player) {
        boolean removed = false;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            if (ActiveEyeItem.is(player.getInventory().getItem(i))) {
                player.getInventory().setItem(i, ItemStack.EMPTY);
                removed = true;
            }
        }
        if (ActiveEyeItem.is(player.containerMenu.getCarried())) {
            player.containerMenu.setCarried(ItemStack.EMPTY);
            removed = true;
        }
        if (removed) player.inventoryMenu.broadcastChanges();
    }

    /** Adds the slot to the player's inventory menu, once. Safe to call any number of times. */
    public static void addTo(Player player) {
        InventoryMenu menu = player.inventoryMenu;
        if (menu == null || find(menu) != null) return;
        if (ADD_SLOT == null) return;
        try {
            ADD_SLOT.invoke(menu, new EyeSlot(new Storage(player)));
        } catch (ReflectiveOperationException | RuntimeException e) {
            ShinobiArts.LOGGER.error("Could not add the dojutsu slot to {}'s inventory", player.getName().getString(), e);
        }
    }

    /** The dojutsu slot of a player's inventory menu, or null. */
    public static Slot find(AbstractContainerMenu menu) {
        for (Slot slot : menu.slots) {
            if (slot instanceof EyeSlot || slot.container instanceof Storage) return slot;
        }
        return null;
    }

    public static boolean isDojutsuContainer(Container container) {
        return container instanceof Storage;
    }

    /** AbstractContainerMenu.addSlot is protected; found by its shape (takes a Slot, returns a Slot) so it works under any mappings. */
    private static Method findAddSlot() {
        for (Method m : AbstractContainerMenu.class.getDeclaredMethods()) {
            if (m.getReturnType() == Slot.class && m.getParameterCount() == 1 && m.getParameterTypes()[0] == Slot.class) {
                m.setAccessible(true);
                return m;
            }
        }
        ShinobiArts.LOGGER.error("AbstractContainerMenu.addSlot not found: the dojutsu slot is disabled");
        return null;
    }

    /** The slot itself: one eye item, with the grey Sharingan when empty. */
    public static final class EyeSlot extends Slot {
        EyeSlot(Storage storage) {
            super(storage, 0, X, Y);
        }

        /** Only a Sharingan item, and only while your eyes are off (switched-on eyes are locked in the slot). */
        @Override
        public boolean mayPlace(ItemStack stack) {
            return accepts(stack) && !ActiveEyeItem.is(getItem());
        }

        @Override
        public boolean mayPickup(Player player) {
            return !ActiveEyeItem.is(getItem());
        }

        @Override
        public int getMaxStackSize() {
            return 1;
        }

        @Override
        public Pair<ResourceLocation, ResourceLocation> getNoItemIcon() {
            return Pair.of(InventoryMenu.BLOCK_ATLAS, EMPTY_ICON);
        }
    }

    /** One-slot container that reads and writes the item stored in the player's NinjaData. */
    static final class Storage implements Container {
        private final Player player;

        Storage(Player player) {
            this.player = player;
        }

        @Override
        public int getContainerSize() {
            return 1;
        }

        @Override
        public boolean isEmpty() {
            return item(player).isEmpty();
        }

        @Override
        public ItemStack getItem(int slot) {
            return slot == 0 ? item(player) : ItemStack.EMPTY;
        }

        @Override
        public ItemStack removeItem(int slot, int amount) {
            ItemStack stack = getItem(slot);
            if (stack.isEmpty() || amount <= 0) return ItemStack.EMPTY;
            ItemStack taken = stack.split(amount);
            if (stack.isEmpty()) setItem(0, ItemStack.EMPTY);
            else setChanged();
            return taken;
        }

        @Override
        public ItemStack removeItemNoUpdate(int slot) {
            ItemStack stack = getItem(slot);
            setItem(0, ItemStack.EMPTY);
            return stack;
        }

        @Override
        public void setItem(int slot, ItemStack stack) {
            NinjaData d = NinjaData.get(player);
            if (slot != 0 || d == null) return;
            d.setDojutsuItem(stack);
            setChanged();
        }

        @Override
        public int getMaxStackSize() {
            return 1;
        }

        @Override
        public void setChanged() {
            if (player instanceof ServerPlayer sp) SharinganManager.updateLook(sp);
        }

        @Override
        public boolean stillValid(Player p) {
            return true;
        }

        @Override
        public void clearContent() {
            setItem(0, ItemStack.EMPTY);
        }
    }
}
