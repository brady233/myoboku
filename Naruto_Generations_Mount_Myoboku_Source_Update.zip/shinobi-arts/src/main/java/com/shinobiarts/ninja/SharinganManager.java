package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.item.SharinganEyeItem;
import com.shinobiarts.network.EyesPacket;
import com.shinobiarts.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

/**
 * The Sharingan's life cycle: evolution (1 -> 2 -> 3 tomoe by level, then the Mangekyou after a near-death
 * experience), its combat strength per stage, eyes taken in PvP, and implanting a taken eye.
 * Stages never skip: each one is unlocked in order, and nobody holds a stage their level can't support.
 */
public final class SharinganManager {
    private static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(0.85f, 0.05f, 0.08f), 1.4f);
    private static final float[] DODGE = {0f, 0.12f, 0.18f, 0.25f, 0.32f};
    private static final double[] COPY_RANGE = {0, 12, 18, 24, 32};

    private SharinganManager() {}

    /** Level needed to reach a tomoe stage (1-3). */
    public static int levelFor(int stage) {
        return switch (stage) {
            case 2 -> Config.i(Config.SHARINGAN_2_LEVEL);
            case 3 -> Config.i(Config.SHARINGAN_3_LEVEL);
            case Dojutsu.MANGEKYOU -> Config.i(Config.MANGEKYOU_LEVEL);
            default -> 1;
        };
    }

    /** Highest tomoe stage (1-3) a player of this level can hold. */
    public static int maxTomoeFor(int level) {
        if (level >= levelFor(3)) return 3;
        if (level >= levelFor(2)) return 2;
        return 1;
    }

    // ---------------------------------------------------------------- evolution

    /** Called on login and after level-ups: unlocks the next tomoe stages in order. */
    public static void checkEvolution(ServerPlayer player) {
        NinjaData d = NinjaData.get(player);
        if (d == null || d.getSharinganStage() <= 0 || d.getSharinganStage() >= 3) return;
        while (d.getSharinganStage() < 3 && d.getLevel() >= levelFor(d.getSharinganStage() + 1)) {
            evolve(player, d, d.getSharinganStage() + 1);
        }
    }

    /** Every few ticks: a 3-tomoe user at the required level who survives at ~5% health awakens the Mangekyou. */
    public static void checkMangekyou(ServerPlayer player, NinjaData d) {
        if (d.getSharinganStage() != 3 || d.getLevel() < levelFor(Dojutsu.MANGEKYOU) || !player.isAlive()) return;
        if (player.getHealth() <= player.getMaxHealth() * Config.d(Config.MANGEKYOU_HEALTH)) {
            evolve(player, d, Dojutsu.MANGEKYOU);
        }
    }

    private static void evolve(ServerPlayer player, NinjaData d, int stage) {
        d.setSharinganStage(stage);
        boolean mangekyou = stage == Dojutsu.MANGEKYOU;
        if (mangekyou) {
            d.setMangekyouDesign(MangekyouDesign.awaken(player.getRandom())); // Itachi, Sasuke or Obito
            d.setSharinganMode(1);                       // eyes that are on turn into the Mangekyou there and then
        }
        player.sendSystemMessage(Component.translatable(mangekyou ? "message.shinobiarts.mangekyou_awakened" : "message.shinobiarts.sharingan_evolved",
                mangekyou ? Dojutsu.sharinganName(stage, d.getMangekyouDesign()) : Dojutsu.sharinganName(stage)).withStyle(ChatFormatting.RED));
        if (mangekyou) EyeTechniques.explain(player, d);
        player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(),
                mangekyou ? SoundEvents.WITHER_SPAWN : SoundEvents.ELDER_GUARDIAN_CURSE, SoundSource.PLAYERS, mangekyou ? 0.6f : 0.5f, 1.4f);
        player.serverLevel().sendParticles(RED, player.getX(), player.getEyeY(), player.getZ(), 40, 0.4, 0.3, 0.4, 0.0);
        if (d.isSharinganActive()) com.shinobiarts.registry.ModSounds.at(player, com.shinobiarts.registry.ModSounds.SHARINGAN_ON);
        ModNetwork.sync(player);
        broadcastEyes(player);
    }

    // ---------------------------------------------------------------- strength per stage

    /** Chance to dodge a hit while the Sharingan is on (Genjutsu raises it, up to 50%). */
    public static float dodgeChance(int stage, float genjutsuMultiplier) {
        return Math.min(0.5f, DODGE[Math.max(0, Math.min(Dojutsu.MANGEKYOU, stage))] * genjutsuMultiplier);
    }

    /** How far away a jutsu can be seen and copied. */
    public static double copyRange(NinjaData d) {
        return COPY_RANGE[Math.max(0, Math.min(Dojutsu.MANGEKYOU, d.activeSharinganStage()))] * d.genjutsuMultiplier();
    }

    // ---------------------------------------------------------------- showing the eyes to other players

    /*
     * A player's "look" is what everyone else needs to draw them, packed in one int:
     * bits 0-2 the Sharingan stage on their face (0 = none), bits 3-4 the Mangekyou pattern,
     * bit 5 Lightning Armor's glow, bit 6 Kamui intangibility, bit 7 a Rasengan in hand, bit 8 still forming it,
     * bit 9 hanging from a ceiling, bits 10-13 the open Eight Gates, bit 14 the ball in hand is a Rasenshuriken.
     */
    public static final int LOOK_LIGHTNING = 1 << 5;
    /** The "stage" drawn on the face for the Byakugan (Sharingan stages are 1-4). */
    public static final int LOOK_BYAKUGAN = 5;
    /** The "stage" drawn on the face for the Rinnegan (while its jutsu are used). */
    public static final int LOOK_RINNEGAN = 6;
    public static final int LOOK_INTANGIBLE = 1 << 6;
    public static final int LOOK_RASENGAN = 1 << 7;
    public static final int LOOK_RASENGAN_FORMING = 1 << 8;
    /** Hanging upside down from a ceiling (Chakra Control). */
    public static final int LOOK_CEILING = 1 << 9;
    /** Bits 10-13: how many of the Eight Gates are open (the aura and veins others see). */
    public static final int LOOK_GATES_SHIFT = 10;
    /** Bit 14: the ball in hand is a Rasenshuriken. */
    public static final int LOOK_RASENSHURIKEN = 1 << 14;
    /** Bit 15: Rock Armor's stone skin. Bit 16: Dance of the Willow's bone blades. Bit 17: Vitality Surge's seal marks. */
    public static final int LOOK_ROCK = 1 << 15, LOOK_BONE = 1 << 16, LOOK_SEAL = 1 << 17;
    /** bits 18-21: their tailed beast (tail count, 0 = none); bits 22-25: its form (1-9 rage tails, 10 cloak, 11 beast). */
    public static final int LOOK_BEAST_SHIFT = 18, LOOK_FORM_SHIFT = 22;

    public static int lookBeast(int look) {
        return (look >> LOOK_BEAST_SHIFT) & 15;
    }

    public static int lookBeastForm(int look) {
        return (look >> LOOK_FORM_SHIFT) & 15;
    }

    public static int lookGates(int look) {
        return (look >> LOOK_GATES_SHIFT) & 15;
    }

    public static int lookStage(int look) {
        return look & 7;
    }

    public static MangekyouDesign lookDesign(int look) {
        return MangekyouDesign.byOrdinal((look >> 3) & 3);
    }

    /** Packs a Sharingan stage and pattern (the pattern only matters for the Mangekyou). */
    public static int packEyes(int stage, MangekyouDesign design) {
        return Math.max(0, Math.min(7, stage)) | (design.ordinal() << 3);
    }

    /**
     * The stage others should see on this player's face: their own while their Sharingan is on; otherwise 3 tomoe
     * if they wear the Sharingan in the dojutsu slot (or their own stage up to that); 0 = no eyes.
     */
    public static int visibleStage(Player player, NinjaData d) {
        if (d.getRinneganShownUntil() > player.level().getGameTime()) return LOOK_RINNEGAN;
        if (d.getActiveDojutsu() == Dojutsu.BYAKUGAN) return LOOK_BYAKUGAN;
        if (d.getActiveDojutsu() == Dojutsu.RINNEGAN) return LOOK_RINNEGAN;
        if (d.isSharinganActive()) return d.activeSharinganStage();
        if (DojutsuSlot.accepts(DojutsuSlot.item(player))) return 3;
        return 0;
    }

    /** Everything other players need to draw this player (see the bit layout above). */
    public static int look(Player player, NinjaData d, long now) {
        int stage = visibleStage(player, d);
        int look = packEyes(stage, stage == Dojutsu.MANGEKYOU ? d.getMangekyouDesign() : MangekyouDesign.ITACHI);
        if (d.getLightningArmorUntil() > now) look |= LOOK_LIGHTNING;
        if (d.isIntangible(now)) look |= LOOK_INTANGIBLE;
        if (d.getRasenganUntil() > now) look |= LOOK_RASENGAN;
        if (d.isRasenganForming(now)) look |= LOOK_RASENGAN_FORMING;
        if (d.getRasenganUntil() > now && d.isRasenshuriken()) look |= LOOK_RASENSHURIKEN;
        if (d.getRockArmorUntil() > now) look |= LOOK_ROCK;
        if (d.getBoneArmorUntil() > now) look |= LOOK_BONE;
        if (d.getSealMarksUntil() > now) look |= LOOK_SEAL;
        if (d.isOnCeiling()) look |= LOOK_CEILING;
        look |= Math.max(0, Math.min(8, d.getGatesOpen())) << LOOK_GATES_SHIFT;
        look |= (d.jin.beast & 15) << LOOK_BEAST_SHIFT;
        look |= (d.jin.form & 15) << LOOK_FORM_SHIFT;
        return look;
    }

    /** Sends this player's look to everyone who can see them (and themselves). */
    public static void broadcastEyes(ServerPlayer player) {
        NinjaData d = NinjaData.get(player);
        if (d == null) return;
        int look = look(player, d, player.level().getGameTime());
        d.setLastLook(look);
        ModNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> player), new EyesPacket(player.getId(), look));
    }

    /** Re-sends the look only if it changed (called every few ticks and whenever eyes or slots change). */
    public static void updateLook(ServerPlayer player) {
        NinjaData d = NinjaData.get(player);
        if (d != null && look(player, d, player.level().getGameTime()) != d.getLastLook()) broadcastEyes(player);
    }

    /** Tells one player what another player looks like (when they come into view). */
    public static void sendEyes(ServerPlayer viewer, ServerPlayer target) {
        NinjaData d = NinjaData.get(target);
        if (d == null) return;
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> viewer),
                new EyesPacket(target.getId(), look(target, d, target.level().getGameTime())));
    }

    // ---------------------------------------------------------------- taking and implanting eyes

    /**
     * A rewarded PvP kill of a Sharingan user: a small chance (eyeTheftChance, 2%) the killer takes one of their eyes
     * (as an item).
     * Born Uchiha keep their bloodline Sharingan; anyone else loses theirs.
     */
    public static void onPvpKill(ServerPlayer killer, ServerPlayer victim) {
        if (!Config.b(Config.EYE_THEFT)) return;
        NinjaData vd = NinjaData.get(victim);
        if (vd == null || vd.getSharinganStage() <= 0) return;
        if (killer.getRandom().nextDouble() >= Config.d(Config.EYE_THEFT_CHANCE)) return;
        int stage = vd.getSharinganStage();
        ItemStack eye = SharinganEyeItem.create(stage, victim.getGameProfile().getName(), vd.getBaseMangekyouDesign());
        if (!killer.getInventory().add(eye) || !eye.isEmpty()) killer.drop(eye, false);
        killer.sendSystemMessage(Component.translatable("message.shinobiarts.eye_taken", victim.getGameProfile().getName(),
                Dojutsu.sharinganName(stage)).withStyle(ChatFormatting.DARK_RED));
        if (vd.getClan() != Clan.UCHIHA) {
            vd.setSharinganStage(0);
            vd.removeBloodline("sharingan");
            victim.sendSystemMessage(Component.translatable("message.shinobiarts.eye_lost", killer.getGameProfile().getName())
                    .withStyle(ChatFormatting.DARK_RED));
            ModNetwork.sync(victim);
            broadcastEyes(victim);
        }
    }

    /**
     * Implants a taken eye. You get the eye's stage, limited by what your level can handle
     * (a Mangekyou eye needs the Mangekyou level), and a Mangekyou eye brings its pattern.
     * Implanting a Mangekyou eye into your own Mangekyou awakens the Eternal Mangekyou.
     * Returns true if the eye was used up.
     */
    public static boolean implant(ServerPlayer player, int eyeStage, MangekyouDesign eyeDesign) {
        NinjaData d = NinjaData.get(player);
        if (d == null || eyeStage <= 0) return false;
        if (eyeStage == Dojutsu.MANGEKYOU && d.getSharinganStage() == Dojutsu.MANGEKYOU && !d.hasEternal()) {
            d.setMangekyouDesign(MangekyouDesign.ETERNAL);   // unlocks the Eternal eyes (triple-tap V)
            d.setSharinganMode(2);
            player.sendSystemMessage(Component.translatable("message.shinobiarts.eternal_awakened",
                    Dojutsu.sharinganName(Dojutsu.MANGEKYOU, MangekyouDesign.ETERNAL)).withStyle(ChatFormatting.RED));
            EyeTechniques.explain(player, d);
            player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.WITHER_SPAWN, SoundSource.PLAYERS, 0.6f, 1.6f);
            player.serverLevel().sendParticles(RED, player.getX(), player.getEyeY(), player.getZ(), 50, 0.4, 0.3, 0.4, 0.0);
            ModNetwork.sync(player);
            broadcastEyes(player);
            return true;
        }
        int allowed = eyeStage == Dojutsu.MANGEKYOU && d.getLevel() >= levelFor(Dojutsu.MANGEKYOU)
                ? Dojutsu.MANGEKYOU : Math.min(eyeStage, maxTomoeFor(d.getLevel()));
        int current = d.getSharinganStage();
        if (current >= eyeStage) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.eye_no_better").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        if (allowed <= current) {
            int needed = eyeStage == Dojutsu.MANGEKYOU && current == 3 ? levelFor(Dojutsu.MANGEKYOU) : levelFor(current + 1);
            player.displayClientMessage(Component.translatable("message.shinobiarts.eye_too_strong", needed).withStyle(ChatFormatting.RED), true);
            return false;
        }
        d.setSharinganStage(allowed);
        if (allowed == Dojutsu.MANGEKYOU) {
            d.setMangekyouDesign(eyeDesign == MangekyouDesign.ETERNAL ? MangekyouDesign.ITACHI : eyeDesign);
            d.setSharinganMode(1);
        }
        player.sendSystemMessage(Component.translatable("message.shinobiarts.eye_implanted",
                        allowed == Dojutsu.MANGEKYOU ? Dojutsu.sharinganName(allowed, d.getMangekyouDesign()) : Dojutsu.sharinganName(allowed))
                .withStyle(ChatFormatting.RED));
        if (allowed == Dojutsu.MANGEKYOU) EyeTechniques.explain(player, d);
        if (allowed < eyeStage) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.eye_limited",
                    eyeStage == Dojutsu.MANGEKYOU && allowed == 3 ? levelFor(Dojutsu.MANGEKYOU) : levelFor(allowed + 1)).withStyle(ChatFormatting.GRAY));
        }
        player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ELDER_GUARDIAN_CURSE, SoundSource.PLAYERS, 0.5f, 1.2f);
        player.serverLevel().sendParticles(RED, player.getX(), player.getEyeY(), player.getZ(), 30, 0.3, 0.2, 0.3, 0.0);
        ModNetwork.sync(player);
        broadcastEyes(player);
        return true;
    }
}
