package com.shinobiarts.entity;

import com.shinobiarts.ninja.FlyingThunderGod;
import com.shinobiarts.registry.ModEntities;
import com.shinobiarts.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;

/**
 * A thrown Flying Thunder God kunai. It sticks where it lands and stays there (it doesn't despawn): while it's
 * there it's a mark its thrower can flash to (and catch it). Whoever it hits carries the mark too. Picking it up
 * (or catching it) takes the mark away.
 */
public class FtgKunaiEntity extends AbstractArrow {
    private boolean marked = true;

    public FtgKunaiEntity(EntityType<? extends FtgKunaiEntity> type, Level level) {
        super(type, level);
    }

    public FtgKunaiEntity(Level level, LivingEntity owner) {
        super(ModEntities.FTG_KUNAI.get(), owner, level);
        setBaseDamage(3.0);
        pickup = owner instanceof Player p && p.getAbilities().instabuild ? Pickup.CREATIVE_ONLY : Pickup.ALLOWED;
    }

    /** No longer a mark (wiped from the menu, or caught): it's just a kunai lying there. */
    public void setUnmarked() {
        marked = false;
    }

    @Override
    protected ItemStack getPickupItem() {
        return new ItemStack(ModItems.FLYING_THUNDER_GOD_KUNAI.get());
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (!level().isClientSide && marked) FlyingThunderGod.kunaiLanded(this);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity target = result.getEntity();
        Entity owner = getOwner();
        float damage = 6.0f;
        if (target.hurt(damageSources().arrow(this, owner == null ? this : owner), damage)) {
            if (target instanceof LivingEntity living && owner instanceof ServerPlayer sp) FlyingThunderGod.markTarget(sp, living);
        }
        setDeltaMovement(getDeltaMovement().multiply(-0.01, -0.1, -0.01));   // falls away from them, like a trident
        playSound(SoundEvents.TRIDENT_HIT, 1.0f, 1.4f);
    }

    @Override
    protected boolean tryPickup(Player player) {
        boolean took = super.tryPickup(player);
        if (took && !level().isClientSide && marked) {
            FlyingThunderGod.kunaiGone(this);
            marked = false;
        }
        return took;
    }

    @Override
    protected void tickDespawn() {
        // stays until it's picked up: it's a mark
    }

    @Override
    public void remove(RemovalReason reason) {
        if (!level().isClientSide && marked && reason.shouldDestroy()) {
            FlyingThunderGod.kunaiGone(this);
            marked = false;
        }
        super.remove(reason);
    }

    @Override
    protected SoundEvent getDefaultHitGroundSoundEvent() {
        return SoundEvents.TRIDENT_HIT_GROUND;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Marked", marked);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        marked = !tag.contains("Marked") || tag.getBoolean("Marked");
    }
}
