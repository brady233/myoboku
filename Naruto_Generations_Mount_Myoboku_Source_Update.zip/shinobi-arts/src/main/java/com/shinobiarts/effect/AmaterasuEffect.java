package com.shinobiarts.effect;

import com.shinobiarts.registry.ModDamage;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/** Black flames: damage every second, can't be put out with water or milk. */
public class AmaterasuEffect extends MobEffect {
    private static final DustParticleOptions BLACK_FLAME = new DustParticleOptions(new Vector3f(0.08f, 0.0f, 0.1f), 2.0f);

    public AmaterasuEffect() {
        super(MobEffectCategory.HARMFUL, 0x1A0A1F);
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        entity.hurt(ModDamage.amaterasu(entity.level()), 2.0f + amplifier);
        if (entity.level() instanceof ServerLevel server) {
            server.sendParticles(BLACK_FLAME, entity.getX(), entity.getY() + entity.getBbHeight() / 2, entity.getZ(),
                    25, entity.getBbWidth() * 0.5, entity.getBbHeight() * 0.4, entity.getBbWidth() * 0.5, 0.0);
        }
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return duration % 20 == 0;
    }

    /** Milk does not cure it. */
    @Override
    public List<ItemStack> getCurativeItems() {
        return new ArrayList<>();
    }
}
