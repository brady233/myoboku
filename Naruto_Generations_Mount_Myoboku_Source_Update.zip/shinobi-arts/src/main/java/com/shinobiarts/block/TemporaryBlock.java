package com.shinobiarts.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * A block made by a jutsu (Wood Release trees and domes, Ice Release prisons and mirrors, iron sand, bone spikes) that
 * breaks by itself after a while and drops nothing. Like the Earth Wall, it only ever goes into empty space (or plants,
 * when jutsu griefing is on) and never into a creature, so nothing it replaces is lost.
 */
public class TemporaryBlock extends Block {
    private static int nextLifetime = -1;
    private final int lifetime;

    public TemporaryBlock(int lifetimeTicks, Properties properties) {
        super(properties);
        this.lifetime = lifetimeTicks;
    }

    /**
     * Puts {@code state} (one of these blocks) at {@code pos} for {@code ticks} ticks (plus a few at random, so a
     * structure crumbles bit by bit). Returns false if the spot is taken by a block or a creature.
     */
    public static boolean place(ServerLevel level, BlockPos pos, BlockState state, int ticks, boolean replacePlants) {
        BlockState existing = level.getBlockState(pos);
        boolean free = existing.isAir() || (replacePlants && existing.canBeReplaced() && existing.getFluidState().isEmpty());
        if (!free || !level.getEntitiesOfClass(LivingEntity.class, new AABB(pos)).isEmpty()) return false;
        nextLifetime = ticks;
        try {
            return level.setBlock(pos, state, 3);
        } finally {
            nextLifetime = -1;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        super.onPlace(state, level, pos, oldState, movedByPiston);
        if (!level.isClientSide && !oldState.is(this)) {
            int ticks = nextLifetime > 0 ? nextLifetime : lifetime;
            level.scheduleTick(pos, this, ticks + level.getRandom().nextInt(10));
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        level.destroyBlock(pos, false);
    }
}
