package com.shinobiarts.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * A block of the Earth Wall: stone, or cobblestone where it's rougher (COBBLE). It crumbles away about 15 seconds
 * after it rises.
 */
public class EarthWallBlock extends Block {
    public static final int LIFETIME_TICKS = 300;
    public static final net.minecraft.world.level.block.state.properties.BooleanProperty COBBLE =
            net.minecraft.world.level.block.state.properties.BooleanProperty.create("cobble");

    public EarthWallBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(COBBLE, false));
    }

    @Override
    protected void createBlockStateDefinition(net.minecraft.world.level.block.state.StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(COBBLE);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        super.onPlace(state, level, pos, oldState, movedByPiston);
        if (!level.isClientSide && !oldState.is(this)) {
            level.scheduleTick(pos, this, LIFETIME_TICKS + level.getRandom().nextInt(40));
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        level.destroyBlock(pos, false);
    }
}
