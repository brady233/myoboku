package com.shinobiarts.item;

import com.shinobiarts.ninja.DojutsuSlot;
import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Sharingan eyes, worn in the dojutsu slot (the extra inventory slot above the off-hand, marked with a grey
 * Sharingan). The wearer's face shows the Sharingan: their own stage while their Sharingan is on, 3 tomoe otherwise.
 * Right-click to put it on (swapping out whatever was in the slot). Purely cosmetic.
 */
public class SharinganItem extends Item {
    public SharinganItem(Properties properties) {
        super(properties.stacksTo(1));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (player instanceof ServerPlayer sp) {
            NinjaData d = NinjaData.get(sp);
            if (d == null) return InteractionResultHolder.fail(held);
            if (com.shinobiarts.item.ActiveEyeItem.is(d.getDojutsuItem())) {
                sp.displayClientMessage(Component.translatable("message.shinobiarts.eyes_in_slot").withStyle(ChatFormatting.GRAY), true);
                return InteractionResultHolder.fail(held);
            }
            DojutsuSlot.addTo(sp);
            ItemStack old = d.getDojutsuItem();
            ItemStack worn = held.copyWithCount(1);
            held.shrink(1);
            d.setDojutsuItem(worn);
            com.shinobiarts.ninja.SharinganManager.updateLook(sp);
            sp.inventoryMenu.broadcastChanges();
            if (!old.isEmpty()) {
                if (held.isEmpty()) player.setItemInHand(hand, old);
                else if (!player.getInventory().add(old)) player.drop(old, false);
            }
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ARMOR_EQUIP_GENERIC, SoundSource.PLAYERS, 1.0f, 1.0f);
            return InteractionResultHolder.consume(player.getItemInHand(hand));
        }
        return InteractionResultHolder.success(held);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.sharingan").withStyle(ChatFormatting.DARK_RED));
        tooltip.add(Component.translatable("tooltip.shinobiarts.sharingan_slot").withStyle(ChatFormatting.GRAY));
        // what your own Sharingan can do (tooltips are only built on the client)
        if (level != null && level.isClientSide) {
            NinjaData d = com.shinobiarts.client.ClientNinjaData.get();
            if (d.getSharinganStage() > 0) {
                com.shinobiarts.ninja.MangekyouDesign best = d.hasEternal() ? com.shinobiarts.ninja.MangekyouDesign.ETERNAL : d.getBaseMangekyouDesign();
                tooltip.add(Component.translatable("tooltip.shinobiarts.your_eyes", d.unlockedSharinganName()).withStyle(ChatFormatting.DARK_RED));
                com.shinobiarts.ninja.EyeTechniques.describe(d.getSharinganStage(), best, false, tooltip);
            }
        }
    }
}
