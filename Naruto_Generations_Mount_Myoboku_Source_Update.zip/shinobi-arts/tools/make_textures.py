"""Generates the mod's original placeholder pixel art. Run: python3 tools/make_textures.py"""
import math
import os
import random
import sys

from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "shinobiarts", "textures")
ITEM = os.path.join(ROOT, "item")
BLOCK = os.path.join(ROOT, "block")
EFFECT = os.path.join(ROOT, "mob_effect")
for d in (ITEM, BLOCK, EFFECT):
    os.makedirs(d, exist_ok=True)


def hexc(h, a=255):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c[:3]) + (c[3],)


class Canvas:
    def __init__(self, size=16):
        self.size = size
        self.px = {}

    def set(self, x, y, c):
        if 0 <= x < self.size and 0 <= y < self.size:
            self.px[(x, y)] = c

    def get(self, x, y):
        return self.px.get((x, y))

    def outline(self, color):
        """Adds a 1px outline around every filled pixel (4-neighbourhood)."""
        add = []
        for y in range(self.size):
            for x in range(self.size):
                if (x, y) in self.px:
                    continue
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    if (x + dx, y + dy) in self.px:
                        add.append((x, y))
                        break
        for p in add:
            self.px[p] = color

    def save(self, path):
        img = Image.new("RGBA", (self.size, self.size), (0, 0, 0, 0))
        for (x, y), c in self.px.items():
            img.putpixel((x, y), c)
        img.save(path)
        return img


OUTLINE = hexc("#1b1c22")

# ---------------------------------------------------------------- kunai
def kunai():
    c = Canvas()
    light, mid, dark = hexc("#e4e9ef"), hexc("#a8b0ba"), hexc("#6b737d")
    for x in range(7, 15):
        y = 15 - x
        if x == 14:
            c.set(x, y, light)
            continue
        c.set(x, y, mid)
        if 8 <= x <= 13:
            c.set(x - 1, y, light)
            c.set(x, y - 1, light)
            c.set(x + 1, y, dark)
            c.set(x, y + 1, dark)
        if 9 <= x <= 12:  # leaf-shaped: widest in the middle
            c.set(x - 1, y - 1, light)
            c.set(x + 1, y + 1, dark)
    wrap_a, wrap_b = hexc("#2e2b3d"), hexc("#55506e")
    for i, x in enumerate(range(4, 7)):
        y = 15 - x
        col = wrap_a if i % 2 == 0 else wrap_b
        c.set(x, y, col)
        c.set(x, y + 1, shade(col, 0.8))
    ring = hexc("#8a929b")
    for (x, y) in ((1, 12), (2, 12), (3, 13), (3, 14), (0, 13), (0, 14), (1, 15), (2, 15)):
        c.set(x, y, ring)
    c.outline(OUTLINE)
    # punch the ring hole back out
    for p in ((1, 13), (2, 13), (1, 14), (2, 14)):
        c.px.pop(p, None)
    return c

# ---------------------------------------------------------------- shuriken
def shuriken():
    c = Canvas()
    light, mid, dark = hexc("#d9dee5"), hexc("#9aa2ac"), hexc("#5d646e")
    cx = cy = 7.5
    for y in range(16):
        for x in range(16):
            dx, dy = x - cx, y - cy
            # rotate 45 degrees so blades point diagonally
            u = (dx + dy) / math.sqrt(2)
            v = (dx - dy) / math.sqrt(2)
            au, av = abs(u), abs(v)
            # four-pointed star: |u|*|v| small, within radius
            r = max(au, av)
            inside = (au <= 1.6 and av <= 6.6 - au * 0.0) or (av <= 1.6 and au <= 6.6)
            inside = inside and (min(au, av) <= 1.9 - (r / 6.6) * 1.3 + 0.0001 or r < 2.6)
            if not inside:
                continue
            if r < 1.0:
                continue  # center hole
            col = mid
            if u < 0 and v > 0 or (u < 0 and abs(v) < 0.8):
                col = light
            elif u > 0 and v < 0 or (u > 0 and abs(v) < 0.8):
                col = dark
            c.set(x, y, col)
    c.outline(OUTLINE)
    for p in ((7, 7), (8, 7), (7, 8), (8, 8)):
        c.px[p] = hexc("#2a2d33")
    return c

# ---------------------------------------------------------------- explosive tag
def explosive_tag():
    c = Canvas()
    paper, paper_d = hexc("#efe2b8"), hexc("#d6c592")
    red = hexc("#b3261e")
    for y in range(1, 15):
        for x in range(5, 11):
            c.set(x, y, paper_d if x == 10 or y == 14 else paper)
    for y in range(3, 13):
        c.set(7, y, red)
        c.set(8, y, red)
    for (x, y) in ((6, 4), (9, 4), (6, 6), (9, 7), (6, 9), (9, 10), (6, 11), (9, 12)):
        c.set(x, y, red)
    c.outline(OUTLINE)
    return c

# ---------------------------------------------------------------- chakra pill
def chakra_pill():
    c = Canvas()
    base, darkc, light = hexc("#7a5a2e"), hexc("#4f3a1c"), hexc("#b08a4e")
    for y in range(16):
        for x in range(16):
            d = math.hypot(x - 7.5, y - 8.0)
            if d <= 4.6:
                col = base
                if (x - 7.5) + (y - 8.0) > 2.2:
                    col = darkc
                if (x - 7.5) + (y - 8.0) < -2.4:
                    col = light
                c.set(x, y, col)
    c.set(6, 5, hexc("#f4e2b6"))
    c.set(5, 6, hexc("#f4e2b6"))
    c.set(9, 9, hexc("#3f7f3a"))
    c.set(8, 10, hexc("#3f7f3a"))
    c.outline(OUTLINE)
    return c

# ---------------------------------------------------------------- chakra paper
def chakra_paper():
    c = Canvas()
    paper, edge, line = hexc("#f5f3ea"), hexc("#d7d3c4"), hexc("#a9c7e8")
    for y in range(2, 14):
        for x in range(3, 13):
            col = paper
            if x == 12 or y == 13:
                col = edge
            elif y in (5, 8, 11) and 4 <= x <= 11:
                col = line
            c.set(x, y, col)
    c.set(11, 2, edge)
    c.set(12, 3, edge)
    c.px.pop((12, 2), None)
    c.outline(hexc("#55534a"))
    return c

# ---------------------------------------------------------------- open jutsu scroll
SCROLL_COLORS = {
    "fire": ("#d23b1f", "#ff9a3c"),
    "water": ("#2c6fd1", "#8fd0ff"),
    "wind": ("#3fa34d", "#b6f2a4"),
    "lightning": ("#d9b21f", "#fff27a"),
    "earth": ("#8a5a2b", "#d3a46a"),
    "yin_yang": ("#4a2a6e", "#f2e6b8"),
    "basic": ("#7b4fc2", "#d2b8ff"),
    "clan": ("#2a1630", "#e0b84c"),
}


def jutsu_scroll(cat):
    main, accent = hexc(SCROLL_COLORS[cat][0]), hexc(SCROLL_COLORS[cat][1])
    c = Canvas()
    wood, wood_l, wood_d = hexc("#6b4423"), hexc("#94643a"), hexc("#3f2814")
    paper, paper_d = hexc("#efe1bb"), hexc("#cdb98c")
    for y in range(3, 13):
        for x in range(4, 12):
            c.set(x, y, paper_d if x in (4, 11) else paper)
    for x in range(3, 13):
        c.set(x, 2, wood_l if x < 8 else wood)
        c.set(x, 13, wood if x < 8 else wood_d)
    for (x, y) in ((2, 2), (13, 2), (2, 13), (13, 13)):
        c.set(x, y, wood_d)
    # colored band + seal
    for x in range(5, 11):
        c.set(x, 5, main)
        c.set(x, 10, main)
    for y in range(6, 10):
        for x in range(6, 10):
            c.set(x, y, main)
    c.set(7, 7, accent)
    c.set(8, 7, accent)
    c.set(7, 8, accent)
    c.set(8, 8, shade(accent, 0.85))
    c.outline(OUTLINE)
    return c

# ---------------------------------------------------------------- closed (rolled) scroll
def rolled_scroll(body_hex, band_hex):
    c = Canvas()
    body = hexc(body_hex)
    band = hexc(band_hex)
    paper = hexc("#efe1bb")
    cap = hexc("#5a3a1e")
    # thick diagonal cylinder from (3,12) to (12,3)
    for t in range(3, 13):
        x, y = t, 15 - t
        for (ox, oy, f) in ((0, 0, 1.0), (-1, 0, 1.15), (0, -1, 1.15), (1, 0, 0.8), (0, 1, 0.8), (-1, -1, 1.25), (1, 1, 0.7)):
            col = band if t in (7, 8) else body
            c.set(x + ox, y + oy, shade(col, f))
    # end caps
    for (x, y) in ((2, 13), (3, 13), (2, 12), (1, 13), (2, 14)):
        c.set(x, y, cap)
    for (x, y) in ((13, 2), (13, 3), (12, 2), (14, 2), (13, 1)):
        c.set(x, y, paper)
    c.set(13, 2, shade(paper, 0.8))
    c.outline(OUTLINE)
    return c

# ---------------------------------------------------------------- earth wall block
def earth_wall():
    rnd = random.Random(1337)
    img = Image.new("RGBA", (16, 16))
    base = hexc("#7d6b55")
    for y in range(16):
        for x in range(16):
            f = 0.85 + rnd.random() * 0.3
            img.putpixel((x, y), shade(base, f))
    # pebbles
    for _ in range(9):
        px, py = rnd.randrange(16), rnd.randrange(16)
        col = hexc("#a39581") if rnd.random() < 0.6 else hexc("#5e5243")
        img.putpixel((px, py), col)
        img.putpixel(((px + 1) % 16, py), shade(col, 0.9))
    # cracks
    for (sx, sy, length) in ((2, 3, 5), (9, 10, 6), (11, 1, 4)):
        x, y = sx, sy
        for _ in range(length):
            img.putpixel((x % 16, y % 16), hexc("#3e352a"))
            x += 1
            y += rnd.choice((0, 1))
    img.save(os.path.join(BLOCK, "earth_wall.png"))
    return img

# ---------------------------------------------------------------- amaterasu icon (18x18)
def amaterasu_icon():
    c = Canvas(18)
    core, mid, rim = hexc("#0b0510"), hexc("#24102e"), hexc("#6a2d8a")
    for y in range(18):
        for x in range(18):
            # teardrop flame: circle at bottom + tapering top
            dx, dy = x - 8.5, y - 11.5
            r = math.hypot(dx, dy)
            top = y < 11.5 and abs(dx) <= (y - 1.5) * 0.45 + 0.4 * math.sin(y * 1.3)
            if r <= 5.2 or (top and y >= 2):
                col = core if r <= 3.0 else mid
                if top and abs(dx) > (y - 1.5) * 0.3:
                    col = mid
                c.set(x, y, col)
    for (x, y) in ((8, 9), (9, 11), (7, 12), (10, 13)):
        c.set(x, y, rim)
    c.outline(rim)
    return c


# ---------------------------------------------------------------- coins (round, square hole)
COIN_COLORS = {"bronze": ("#c27a3a", "#e9a76a", "#7a4418"), "silver": ("#c9d1d9", "#f4f7fa", "#7d8792"),
               "gold": ("#f2c230", "#fff0a0", "#a5780c")}


def coin(kind):
    base, light, dark = (hexc(h) for h in COIN_COLORS[kind])
    c = Canvas()
    for y in range(16):
        for x in range(16):
            d = math.hypot(x - 7.5, y - 7.5)
            if d <= 6.3:
                col = base
                if d > 5.1:
                    col = dark if (x + y) > 15 else light
                elif (x - 7.5) + (y - 7.5) < -5:
                    col = light
                c.set(x, y, col)
    for y in range(6, 10):  # square hole
        for x in range(6, 10):
            c.px.pop((x, y), None)
    for x in range(6, 10):
        c.set(x, 5, dark)
        c.set(x, 10, light)
    for y in range(6, 10):
        c.set(5, y, dark)
        c.set(10, y, light)
    c.outline(OUTLINE)
    for y in range(6, 10):
        for x in range(6, 10):
            c.px.pop((x, y), None)
    return c


# ---------------------------------------------------------------- frog-shaped coin purse
def frog_wallet():
    c = Canvas()
    green, light, dark = hexc("#4caf3a"), hexc("#86d96a"), hexc("#2c6e21")
    for y in range(16):
        for x in range(16):
            if ((x - 7.5) / 6.2) ** 2 + ((y - 9.5) / 5.2) ** 2 <= 1.0:
                col = green
                if y > 11:
                    col = dark
                elif x + y < 13:
                    col = light
                c.set(x, y, col)
    for ex in (4, 11):  # eye bumps
        for y in range(2, 6):
            for x in range(ex - 2, ex + 2):
                if math.hypot(x - (ex - 0.5), y - 3.5) <= 2.0:
                    c.set(x, y, green)
        c.set(ex - 1, 3, hexc("#ffffff"))
        c.set(ex, 3, hexc("#ffffff"))
        c.set(ex - 1, 4, hexc("#111111"))
        c.set(ex, 4, hexc("#ffffff"))
    for x in range(5, 11):  # mouth / clasp
        c.set(x, 9, dark)
    c.set(4, 8, dark)
    c.set(11, 8, dark)
    c.set(7, 12, hexc("#e8c84a"))
    c.set(8, 12, hexc("#e8c84a"))
    c.outline(OUTLINE)
    return c


# ---------------------------------------------------------------- exp bottle
def exp_bottle():
    c = Canvas()
    glass, liquid, glow = hexc("#cfe9f2", 220), hexc("#2fd18c"), hexc("#b6ffd9")
    cork = hexc("#8a5a2b")
    for y in range(1, 4):
        for x in range(6, 10):
            c.set(x, y, cork)
    for y in range(4, 6):
        for x in range(6, 10):
            c.set(x, y, glass)
    for y in range(6, 15):
        for x in range(16):
            if math.hypot(x - 7.5, y - 10.3) <= 4.6:
                c.set(x, y, liquid if y >= 8 else glass)
    c.set(5, 9, glow)
    c.set(6, 8, glow)
    c.set(9, 11, glow)
    c.set(8, 12, glow)
    c.set(6, 12, hexc("#ffffff"))
    c.outline(OUTLINE)
    return c


# ---------------------------------------------------------------- placeholder release icons (64x64)
def octagon_icon(fill_hex, symbol):
    from PIL import ImageDraw
    big = 256
    img = Image.new("RGBA", (big, big), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    r, cx = 118, big / 2
    pts = [(cx + r * math.cos(math.radians(22.5 + 45 * i)), cx + r * math.sin(math.radians(22.5 + 45 * i))) for i in range(8)]
    d.polygon(pts, fill=(0, 0, 0, 255))
    r2 = r - 12
    pts2 = [(cx + r2 * math.cos(math.radians(22.5 + 45 * i)), cx + r2 * math.sin(math.radians(22.5 + 45 * i))) for i in range(8)]
    d.polygon(pts2, fill=hexc(fill_hex))
    ink = (20, 20, 20, 255)
    if symbol == "moon":
        d.ellipse((70, 60, 190, 180), fill=ink)
        d.ellipse((100, 48, 210, 158), fill=hexc(fill_hex))
    elif symbol == "sun":
        d.ellipse((92, 92, 164, 164), fill=ink)
        for i in range(8):
            a = math.radians(45 * i)
            d.line((cx + 50 * math.cos(a), cx + 50 * math.sin(a), cx + 78 * math.cos(a), cx + 78 * math.sin(a)), fill=ink, width=12)
    elif symbol == "taijitu":
        box = (56, 56, 200, 200)
        d.ellipse(box, fill=(245, 240, 225, 255), outline=ink, width=8)
        d.pieslice(box, 90, 270, fill=ink)
        d.ellipse((92, 56, 164, 128), fill=ink)
        d.ellipse((92, 128, 164, 200), fill=(245, 240, 225, 255))
        d.ellipse((118, 82, 138, 102), fill=(245, 240, 225, 255))
        d.ellipse((118, 154, 138, 174), fill=ink)
        d.ellipse(box, outline=ink, width=8)
    elif symbol == "spiral":
        for i, rr in enumerate((70, 48, 26)):
            d.arc((cx - rr, cx - rr + i * 6, cx + rr, cx + rr + i * 6), 200, 520, fill=ink, width=12)
        d.ellipse((cx - 10, cx + 2, cx + 10, cx + 22), fill=ink)
    return img.resize((64, 64), Image.LANCZOS)


def main():
    out = {}
    out["kunai"] = kunai().save(os.path.join(ITEM, "kunai.png"))
    out["shuriken"] = shuriken().save(os.path.join(ITEM, "shuriken.png"))
    out["explosive_tag"] = explosive_tag().save(os.path.join(ITEM, "explosive_tag.png"))
    out["chakra_pill"] = chakra_pill().save(os.path.join(ITEM, "chakra_pill.png"))
    out["chakra_paper"] = chakra_paper().save(os.path.join(ITEM, "chakra_paper.png"))
    out["blank_scroll"] = rolled_scroll("#e3d3a6", "#b99c63").save(os.path.join(ITEM, "blank_scroll.png"))
    for cat in SCROLL_COLORS:
        out["scroll_" + cat] = jutsu_scroll(cat).save(os.path.join(ITEM, "scroll_" + cat + ".png"))
    for nat in ("fire", "water", "wind", "lightning", "earth", "yin_yang"):
        body, band = SCROLL_COLORS[nat]
        out["nature_scroll_" + nat] = rolled_scroll(body, band).save(os.path.join(ITEM, "nature_scroll_" + nat + ".png"))
    # Coins and the wallet use the provided art when it's in tools/source_art (drawn versions are fallbacks).
    source = os.path.join(os.path.dirname(os.path.abspath(__file__)), "source_art")
    for k in COIN_COLORS:
        provided = os.path.join(source, "coin_" + k + ".png")
        if os.path.exists(provided):
            img = Image.open(provided).convert("RGBA").resize((32, 32), Image.LANCZOS)
            img.save(os.path.join(ITEM, k + "_ryo.png"))
            out[k + "_ryo"] = img
        else:
            out[k + "_ryo"] = coin(k).save(os.path.join(ITEM, k + "_ryo.png"))
    provided = os.path.join(source, "frog_wallet.png")
    if os.path.exists(provided):
        img = Image.open(provided).convert("RGBA")
        img.save(os.path.join(ITEM, "frog_wallet.png"))
        out["frog_wallet"] = img
    else:
        out["frog_wallet"] = frog_wallet().save(os.path.join(ITEM, "frog_wallet.png"))
    out["exp_bottle"] = exp_bottle().save(os.path.join(ITEM, "exp_bottle.png"))
    nature_dir = os.path.join(ROOT, "nature")
    os.makedirs(nature_dir, exist_ok=True)
    # Placeholders until the real Yin / Yang / Ninjutsu pictures are provided (won't overwrite provided art).
    for name, (fill, sym) in {"yin_yang": ("#7a4fb0", "taijitu"), "ninjutsu": ("#b07cf0", "spiral")}.items():
        path = os.path.join(nature_dir, name + ".png")
        marker = os.path.join(nature_dir, "." + name + ".provided")
        if not os.path.exists(marker):
            octagon_icon(fill, sym).save(path)
    # Release item icons: the nature icons scaled to 32x32.
    for name in ("fire", "water", "wind", "lightning", "earth", "yin_yang", "ninjutsu"):
        src = os.path.join(nature_dir, name + ".png")
        if os.path.exists(src):
            Image.open(src).convert("RGBA").resize((32, 32), Image.LANCZOS).save(os.path.join(ITEM, "release_" + name + ".png"))
            out["release_" + name] = Image.open(os.path.join(ITEM, "release_" + name + ".png"))
    out["earth_wall"] = earth_wall()
    out["amaterasu"] = amaterasu_icon().save(os.path.join(EFFECT, "amaterasu.png"))

    if len(sys.argv) > 1:  # optional preview sheet
        scale = 4
        names = list(out)
        cols = 6
        rows = (len(names) + cols - 1) // cols
        sheet = Image.new("RGBA", (cols * 20 * scale, rows * 20 * scale), (70, 70, 80, 255))
        for i, n in enumerate(names):
            im = out[n].convert("RGBA").resize((16 * scale, 16 * scale), Image.NEAREST)
            sheet.alpha_composite(im, ((i % cols) * 20 * scale + scale, (i // cols) * 20 * scale + scale))
        sheet.save(sys.argv[1])
    print("generated", len(out), "textures")


if __name__ == "__main__":
    main()
